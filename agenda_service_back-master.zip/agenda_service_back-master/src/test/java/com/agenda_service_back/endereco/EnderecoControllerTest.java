package com.agenda_service_back.endereco;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnderecoControllerTest {

    @Test
    void getAllEnderecos() {
    }

    @Test
    void getEnderecoById() {
    }

    @Test
    void createEndereco() {
    }

    @Test
    void updateEndereco() {
    }

    @Test
    void deleteEndereco() {
    }
}