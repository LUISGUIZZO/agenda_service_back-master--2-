package com.agenda_service_back.cliente;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ClienteTest {
    @Test
    @DisplayName("Validar se um cpf invalido esta salvando no banco")
    void validarcpf() throws Exception{
        Cliente cliente = new Cliente();
        cliente.setCliente_cpf
        cliente.setCliente_nome
        cliente.setCliente_email
        cliente.setCliente_dataNascimento
    }

}
