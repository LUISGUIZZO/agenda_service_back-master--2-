package com.agenda_service_back.cliente;

public class ClienteDTO {
}
