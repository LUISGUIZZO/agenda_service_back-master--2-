package com.agenda_service_back.usuarios;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioControllerTest {

    @Test
    void getAllUsuarios() {
    }

    @Test
    void getUsuarioById() {
    }

    @Test
    void createUsuario() {
    }

    @Test
    void updateUsuario() {
    }

    @Test
    void deleteUsuario() {
    }
}