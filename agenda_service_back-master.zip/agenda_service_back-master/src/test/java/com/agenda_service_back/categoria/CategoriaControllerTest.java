package com.agenda_service_back.categoria;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CategoriaControllerTest {

    @Test
    void getAllCategorias() {
    }

    @Test
    void getCategoriaById() {
    }

    @Test
    void createCategoria() {
    }

    @Test
    void updateCategoria() {
    }

    @Test
    void deleteCategoria() {
    }
}